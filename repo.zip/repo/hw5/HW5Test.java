/** Tests of HW5
 *  @author P. N. Hilfinger
 */
public class HW5Test {

    public static void main(String[] args) {
        System.exit(ucb.junit.textui.runClasses(LastBitTest.class,
                                                NybblesTest.class,
                                                CompactLinkedListTest.class));
    }

}

