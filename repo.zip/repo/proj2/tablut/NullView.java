package tablut;

/**
 * A View that does nothing.
 *
 * @author P. N. Hilfinger
 */
class NullView implements View {

    @Override
    public void update(Controller controller) {
    }
}
