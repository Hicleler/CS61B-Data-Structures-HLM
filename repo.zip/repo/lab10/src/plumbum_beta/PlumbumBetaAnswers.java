package plumbum_beta;

public class PlumbumBetaAnswers {
	public static final String answerToQuestion1A = "NullPointerException";
	public static final String answerToQuestion1B = "24";
	public static final String answerToQuestion1C = "top";

	public static final String answerToQuestion2 = "forgot to intialize";

	public static final String answerToQuestion3A = "60";
	public static final String answerToQuestion3B = "Should compare size of entries";
	public static final String answerToQuestion3C = "13";
}
